See `Official Github Repo <https://github.com/ShaanAu/strangerqueries>`_.
